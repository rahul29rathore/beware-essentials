@extends('layouts.app')
@section('content')
<section class="main-title-section-wrapper default" style="background:url({{asset('assets/images/img1-1.jpg')}}) left top / auto repeat scroll;">
    <div class="container">
        <div class="main-title-section">
            <h1>Support</h1>
        </div>
        <div class="breadcrumb">
            <a href="/">Home</a>
            <span class="fa default"></span>
            <span class="current">Support</span>
        </div>
    </div>
</section>
<div class="container">
	<section id="primary" class="content-full-width">
        <div class="row pt-0">
            <div class="col-lg-12 col-md-12" data-aos="fade-left">
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

                <h4>Where can I get some?</h4>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
            </div>
        </div>
    </section>
</div>
@endsection